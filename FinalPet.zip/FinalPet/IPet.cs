﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalPet
{
    interface IPet
    {
        //methods
        void Bird();
        void Cat();
        void Dog();

    }
}
